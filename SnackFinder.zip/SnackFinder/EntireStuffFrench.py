import time
inventory = {}  # Your Inventory


# Account Registration & Login
is_registered = False


def registration():
    counter = 4
    print("-----INSCRIVEZ-VOUS CI-DESSOUS-----")
    reg_user = input("Entrez votre nom d'utilisateur: ")
    while len(reg_user) < 4:
        reg_user = input("Le nom d'utilisatuer doit comporter au moins 4 caractères: ")
    reg_password = input("Tapez votre mot de passe: ")
    reg_password2 = input("Confirmer votre mot de passe: ")

    while reg_password != reg_password2:
        print("-" * 30)
        print("Vos mots de passe ne correspondent pas. Réessayer.\n")
        reg_user = input("Entrez votre nom d'utilisateur: ")
        while len(reg_user) < 4:
            reg_user = input("Le nom d'utilisatuer doit comporter au moins 4 caractères: ")
        reg_password = input("Tapez votre mot de passe: ")
        reg_password2 = input("Confirmer votre mot de passe: ")
    while len(reg_password) < 7:
        reg_password = input("Tapez un mot de passe de plus de 7 caractères: ")
        reg_password2 = input("Confirmer votre mot de passe: ")
    else:
        print("\n-----COMPTE CRÉÉ-----\n")

    print("-----CONNEXION CI-DESSOUS-----")

    login_user = input("Nom d'utilisateur: ")
    login_pass = input("Mot de passe: ")
    while login_user != reg_user or login_pass != reg_password:
        counter -= 1
        print("\nTentatives restantes:", counter + 1)
        login_user = input("\nNom d'utilisateur: ")
        login_pass = input("Mot de passe: ")
        if counter == 1:
            print("-" * 40)
            print("-- AVERTISSEMENT! Ceci est votre dernière tentative.")
            print("-" * 40)
        if counter == 0:
            print("Votre session a expiré. Sortie de l'application.")
            time.sleep(2)
            break
    else:
        print("\nChargement...")
        time.sleep(2)
        print("\n-----Connexion réussie-----")
        print("{0:10}{1}".format("     Bonjour ", reg_user.upper()))
        is_registered = True
        if is_registered is True:
            menu_option()


print("\n\t\t\t\t\tBIENVENUE\tCHEZ 'SNACK FINDER'")


# Function for adding snack to inventory.
def op1_add_snack():
    snack = input("\nQuelle collation voulez-vous ajouter: ")
    if snack not in inventory:
        amount = input("Quantité à ajouter: ")
        while int(amount) < 1:
            amount = input("\nEntrée non valide, veuillez entrer au moins UNE quantité: ")
        inventory[snack] = int(amount)
        print("\n" + amount, "'" + snack + "' ont été ajoutés à votre inventaire.")
    else:
        print("'" + snack + "' existe déjà dans votre inventaire.")


# Function to search/look up a snack.
def op2_search_snack():
    snack = input("\nQuelle collation recherchez-vous: ")
    if snack in inventory:
        print("\nVous avez actuellement " + str(inventory[snack]) + " '" + snack + "'.")
    else:
        print("'" + snack + "'", "n'est pas dans votre inventaire.")


# Function to update a snack's quantity.
def op3_update_snack():
    snack = input("\nQuelle collation voulez-vous mettre à jour: ")
    if snack in inventory:
        new_amount = int(input("Quelle est la nouvelle quantité: "))
        inventory[snack] = int(new_amount)
        while int(new_amount) < 0:
            new_amount = int(input("Entrée non valide, la quantité peut être inférieure à zéro: "))
        print("\n'" + str(snack) + "' la quantité a été mise à jour pour " + str(new_amount) + ".")
        print("L'inventaire a été mis à jour.")
    else:
        print("'" + snack + "' n'existe pas dans votre inventaire. Veuillez aller dans le menu pour l'ajouter.")


# Function to delete a snack from inventory.
def op4_delete_snack():
    snack = input("\nQuelle collation voulez-vous supprimer: ")
    if snack in inventory:
        del inventory[snack]
        print("\n'" + snack + "' a été supprimé de votre inventaire.\n")
    else:
        print("'" + snack + "' n'existe pas dans votre inventaire.\n")


# Function to list all snacks and their quantity in your inventory.
def op5_list_snacks():
    print("\n{0:15} {1:15}".format("Casse-croûte:", "Quantité:"))
    print("_" * 25)
    for snack in inventory:
        print("{0:15} {1:>5}".format(snack, inventory[snack]))


# Useless shit lol, just bunch of new lines.
def space():
    print("\n\n\n\n\n\n\n\n\n\n")


# Function to Exit app.
def op6_quit_app():
    print("Merci d'utiliser SnackFinder. À la prochaine.")
    print("""
                    /\             /\ 
                            |
                    _______________       
                    \               /
                     \             /
                      \___________/

    """)
    time.sleep(2)


# Simple function for menu & option screen.
def menu_option():
    option_select = int(input("""
-------------------------------------
|         VOTRE INVENTAIRE          |
=====================================
| 1 - Ajouter une collation.        |
| 2 - Rechercher une collation.     |
| 3 - Mettre à jour une collation.  |
| 4 - Supprimer une collation.      |
| 5 - Liste des collations.         |
| 6 - Quitter.                      |
=====================================
"""
))
    if option_select == 1:
        op1_add_snack()
        time.sleep(1)
        space()
        menu_option()
    elif option_select == 2:
        op2_search_snack()
        time.sleep(1)
        space()
        menu_option()
    elif option_select == 3:
        op3_update_snack()
        time.sleep(1)
        space()
        menu_option()
    elif option_select == 4:
        op4_delete_snack()
        time.sleep(1)
        space()
        menu_option()
    elif option_select == 5:
        op5_list_snacks()
        time.sleep(1)
        space()
        menu_option()
    else:
        space()
        op6_quit_app()


registration()
