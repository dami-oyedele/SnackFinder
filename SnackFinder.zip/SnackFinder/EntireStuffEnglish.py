import time
inventory = {}  # Your Inventory


# Account Registration & Login
is_registered = False


def registration():
    counter = 4
    print("-----SIGN UP BELOW-----")
    reg_user = input("Enter your username: ")
    while len(reg_user) < 4:
        reg_user = input("Username must be at least 4 characters long: ")
    reg_password = input("Enter your password: ")
    reg_password2 = input("Confirm your password: ")

    while reg_password != reg_password2:
        print("-" * 30)
        print("Your passwords did not match. Try again.\n")
        reg_user = input("Enter your username: ")
        while len(reg_user) < 4:
            reg_user = input("Username must be at least 4 characters long: ")
        reg_password = input("Enter your password: ")
        reg_password2 = input("Confirm your password: ")
    while len(reg_password) < 7:
        reg_password = input("Type a password longer than 7 characters: ")
        reg_password2 = input("Confirm your password: ")
    else:
        print("\n-----Account Created-----\n")

    print("-----LOGIN BELOW-----")

    login_user = input("Username: ")
    login_pass = input("Password: ")
    while login_user != reg_user or login_pass != reg_password:
        counter -= 1
        print("\nRemaining attempts left:", counter + 1)
        login_user = input("\nUsername: ")
        login_pass = input("Password: ")
        if counter == 1:
            print("-" * 40)
            print("-- WARNING! This is your last attempt.")
            print("-" * 40)
        if counter == 0:
            print("Your session has timed out. Exiting app.")
            time.sleep(2)
            break
    else:
        print("\nLoading...")
        time.sleep(2)
        print("\n-----Login Successful-----")
        print("{0:10}{1}".format("     Welcome ", reg_user.upper()))
        is_registered = True
        if is_registered is True:
            menu_option()


print("\n\t\t\t\t\tWELCOME\tTO 'SNACK FINDER'")


# Function for adding snack to inventory.
def op1_add_snack():
    snack = input("\nWhat snack do you want to add: ")
    if snack not in inventory:
        amount = input("Quantity to add: ")
        while int(amount) < 1:
            amount = input("\nInvalid entry, please enter at least ONE quantity: ")
        inventory[snack] = int(amount)
        print("\n" + amount, "'" + snack + "' have been added to your inventory.")
    else:
        print("'" + snack + "' already exists in the inventory.")


# Function to search/look up a snack.
def op2_search_snack():
    snack = input("\nWhat snack are you looking for: ")
    if snack in inventory:
        print("\nYou currently have " + str(inventory[snack]) + " '" + snack + "'.")
    else:
        print("'" + snack + "'", "is not in your inventory.")


# Function to update a snack's quantity.
def op3_update_snack():
    snack = input("\nWhat snack do you want to update: ")
    if snack in inventory:
        new_amount = int(input("What is the new quantity: "))
        inventory[snack] = int(new_amount)
        while int(new_amount) < 0:
            new_amount = int(input("Invalid entry, quantity cannot be below zero: "))
        print("\n'" + str(snack) + "' quantity has been updated to " + str(new_amount) + ".")
        print("Inventory has been updated.")
    else:
        print("'" + snack + "' doesn't exist in your inventory. Please go to the menu to add it.")


# Function to delete a snack from inventory.
def op4_delete_snack():
    snack = input("\nWhat snack do you want to delete: ")
    if snack in inventory:
        del inventory[snack]
        print("\n'" + snack + "' has been deleted from your inventory.\n")
    else:
        print("'" + snack + "' doesn't exist in your inventory.\n")


# Function to list all snacks and their quantity in your inventory.
def op5_list_snacks():
    print("\n{0:15} {1:15}".format("Snack:", "Quantity:"))
    print("_" * 25)
    for snack in inventory:
        print("{0:15} {1:>5}".format(snack, inventory[snack]))


# Useless shit lol, just bunch of new lines.
def space():
    print("\n\n\n\n\n\n\n\n\n\n")


# Function to Exit app.
def op6_quit_app():
    print("Thank you for using SnackFinder. See you next time.")
    print("""
                    /\             /\ 
                            |
                    _______________       
                    \               /
                     \             /
                      \___________/

    """)
    time.sleep(2)


# Simple function for menu & option screen.
def menu_option():
    option_select = int(input("""
------------------------
|    YOUR INVENTORY    |
========================
| 1 - Add a snack.     |
| 2 - Look up a snack. |
| 3 - Update a snack.  |
| 4 - Delete a snack.  |
| 5 - List of snacks.  |
| 6 - Quit.            |
========================
"""
))
    if option_select == 1:
        op1_add_snack()
        time.sleep(1)
        space()
        menu_option()
    elif option_select == 2:
        op2_search_snack()
        time.sleep(1)
        space()
        menu_option()
    elif option_select == 3:
        op3_update_snack()
        time.sleep(1)
        space()
        menu_option()
    elif option_select == 4:
        op4_delete_snack()
        time.sleep(1)
        space()
        menu_option()
    elif option_select == 5:
        op5_list_snacks()
        time.sleep(1)
        space()
        menu_option()
    else:
        space()
        op6_quit_app()


registration()
