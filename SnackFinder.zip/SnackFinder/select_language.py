import tkinter
select_language = int(input("""
---------------
|  LANGUAGE   |
---------------
| 1 - English |
| 2 - French  |
---------------\n"""))
while select_language != 0:
    if select_language == 1:
        import EntireStuffEnglish
    elif select_language == 2:
        import EntireStuffFrench
    else:
        from EntireStuffEnglish import op6_quit_app
        quit()
